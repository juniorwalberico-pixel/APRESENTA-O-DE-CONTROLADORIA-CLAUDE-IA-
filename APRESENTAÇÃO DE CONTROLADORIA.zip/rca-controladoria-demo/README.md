# RCA · Controladoria & Finanças — demo

> **A empresa e todos os dados são fictícios.** "Movyra Logística" não existe. Números, clientes, sócios, vendedores e comentários foram gerados só para ilustrar. Qualquer semelhança com empresas reais é coincidência.

Uma apresentação financeira mensal para **Conselho de Administração**, feita como um site de uma página só: 21 telas navegáveis com DRE, orçamento, composição de custos, fluxo de caixa realizado e projetado, inadimplência, indicadores e distribuição de lucro.

A ideia é trocar o PowerPoint cheio de tabelas coladas por algo que o conselho lê rápido, com números que conferem entre si.

![Capa](docs/screenshots/01-capa.jpg)

## O que tem dentro

| Bloco | Telas |
|---|---|
| Resultado | DRE do mês e acumulado, principais variações frente a julho com comentários, faturamento e margem por cliente |
| Custo | Composição do CSP por modal, por competência e por caixa |
| Orçamento | Previsto × realizado com gráfico de variação; comparativos mês a mês, ano contra ano e acumulado |
| Caixa | DFC realizado, geração de caixa operacional × mensal, ponte de caixa (cascata), DFC projetado até dezembro e premissas |
| Recebíveis | Recebimento por cliente, concentração, aging da inadimplência, protestado × não protestado, atraso por vendedor |
| Indicadores | Oxigenação da receita, liquidez corrente, receita por colaborador, PMR, PMP e break even, com histórico |
| Sócios | Distribuição de lucro mensal e consumo da ata por sócio |

![DRE](docs/screenshots/02-dre.jpg)
![Composição do CSP](docs/screenshots/03-composicao-csp.jpg)
![DFC realizado](docs/screenshots/04-dfc-realizado.jpg)
![DFC projetado](docs/screenshots/05-dfc-projetado.jpg)
![Indicadores](docs/screenshots/06-indicadores.jpg)
![Distribuição de lucro](docs/screenshots/07-distribuicao-lucro.jpg)

### No celular

![Versão mobile](docs/screenshots/08-mobile.jpg)

## Como abrir

É um arquivo só (`index.html`, cerca de 0,8 MB), sem instalação e sem internet: fontes, biblioteca 3D e dados vão embutidos.

- **No computador:** baixe e abra `index.html` no navegador.
- **Pelo GitHub Pages:** em *Settings → Pages*, escolha a branch `main` e a pasta `/ (root)`. O site fica em `https://<seu-usuario>.github.io/<nome-do-repo>/`.

**Navegação:** roda do mouse, setas do teclado, os pontos na lateral (no computador) ou deslizar o dedo no celular. Na capa dá para arrastar a cena 3D.

## Detalhes que importam

- **Os números batem entre si.** O faturamento por cliente fecha na receita bruta da DRE, o CSP por modal fecha no custo da DRE, o CSP de caixa fecha na saída do DFC, a ponte de caixa fecha no saldo final, a distribuição por sócio fecha na linha do DFC e o aging fecha no total por vendedor.
- **Cor pela natureza da linha.** Custo que sobe fica vermelho, receita que sobe fica verde. A cor mostra o efeito no resultado, não só o sinal.
- **Gráficos em SVG feitos à mão**, sem biblioteca de gráficos. Paleta conferida para contraste em fundo escuro.
- **Responsivo:** testado em 1280×720, 1366×768, 1440×900, 1920×1080 e em celular (360 e 390 px), sem conteúdo cortado.
- **Reduzir movimento:** com essa opção ligada no sistema, a câmera da cena 3D fica parada.

## Tecnologia

HTML, CSS e JavaScript puros, num arquivo só. A cena 3D da capa usa [Three.js](https://threejs.org/) r128. As fontes são [Chakra Petch](https://fonts.google.com/specimen/Chakra+Petch) e [Jost](https://fonts.google.com/specimen/Jost).

## Créditos e licenças de terceiros

- **Three.js** — MIT License, © 2010-2021 three.js authors. Veja [`licenses/three.js-MIT.txt`](licenses/three.js-MIT.txt).
- **Chakra Petch** — SIL Open Font License 1.1, © 2018 The Chakra Petch Project Authors. Veja [`licenses/ChakraPetch-OFL.txt`](licenses/ChakraPetch-OFL.txt).
- **Jost** — SIL Open Font License 1.1, © 2020 The Jost Project Authors. Veja [`licenses/Jost-OFL.txt`](licenses/Jost-OFL.txt).
